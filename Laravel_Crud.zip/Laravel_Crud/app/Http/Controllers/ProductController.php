<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\product;

class ProductController extends Controller
{
    public function index()
    {
        return view('products.index',[
            'products'=>Product::get()
        ]);
    }
    public function create()
    {
        return view('products.create');
    }
    public function store(Request $request)
    {
        $request->validate([
            'name'=>'required',
            'description'=>'required',
            'image'=>'required|mimes:jpeg,png,jpg,gif|max:10000',
        ]);
        //dd($request->all());
        $imageName= time().'.'.$request->image->extension();
        $request->image->move(public_path('products'),$imageName);
        //dd($imageName);
        $product = new product();
        $product->image= $imageName;
        $product->name= $request->name;
        $product->description= $request->description;
        $product->save();
        return back()->withSuccess('Product update success!!');
    }
    public function edit($id)
    {
        //dd($id);
        $product = product::where('id',$id)->first();
        //here , data fetch from db and use "product" from model.
        return view('products.edit', ['product'=>$product]);
    }
    public function update(Request $request , $id)
    {
        $request->validate([
            'name'=>'required',
            'description'=>'required',
            'image'=>'nullable|mimes:jpeg,png,jpg,gif|max:10000',
        ]);
        $product = Product::where('id',$id)->first();
        if(isset($request->image))
        {
        $imageName= time().'.'.$request->image->extension();
        $request->image->move(public_path('products'),$imageName);
        $product->image= $imageName;
        }                          
        $product->name= $request->name;
        $product->description= $request->description;
        $product->save();
        return back()->withSuccess('Product updated !!');
    }
    public function delete($id)
    {
        $product = Product::where('id',$id)->first();
        $product->delete();
        return back()->withSuccess('products.index');
       
    }
    public function show($id)
    {
        
        $product = Product::where('id',$id)->first();
        //here , data fetch from db and use "product" from model.
        return view('products.show', ['product'=>$product]);
    }
}
