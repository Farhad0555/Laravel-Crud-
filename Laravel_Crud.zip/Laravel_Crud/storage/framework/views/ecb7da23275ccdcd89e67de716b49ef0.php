
<?php $__env->startSection('main'); ?>
 <section class='py-5'>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <form method='POST' action="<?php echo e(route('products.update',$product->id)); ?>"  enctype='multipart/form-data'>
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                            <div class="card-header">
                                <h4 class='text-muted'>Update the info of :: <?php echo e($product->name); ?></h4>
                            </div>
                            <div class="card-body">
                            <div class="form-group row py-2">
                                <label class="col-md-3 text-center">Name</label>
                                <div class="col-md-9">
                                    <input type="text" name='name' class='form-control' value="<?php echo e(old('name',$product->name)); ?>">
                                    <?php if($errors->has('name')): ?>
                                    <span class='text-danger'><?php echo e($errors->first('name')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group row py-2">
                                <label class="col-md-3 text-center">Description </label>
                                <div class="col-md-9">
                                    <input type="text" name='description' class='form-control' value="<?php echo e(old('description',$product->description)); ?>">
                                    <?php if($errors->has('description')): ?>
                                    <span class='text-danger'><?php echo e($errors->first('description')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group row py-2">
                                <label class="col-md-3 text-center"> Image </label>
                                <div class="col-md-9">
                                    <input type="file" name='image' class='form-control' value="<?php echo e(old('image',$product->image)); ?>">
                                    <?php if($errors->has('image')): ?>
                                    <span class='text-danger'><?php echo e($errors->first('image')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group row py-2">
                                <label class="col-md-3 text-center"></label>
                                <div class="col-md-9">
                                    <input type="submit" name='updateBTN' class='btn btn-outline-success form-control'>
                                </div>
                            </div>
                            </div>
                            </form>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\crud\resources\views/products/edit.blade.php ENDPATH**/ ?>