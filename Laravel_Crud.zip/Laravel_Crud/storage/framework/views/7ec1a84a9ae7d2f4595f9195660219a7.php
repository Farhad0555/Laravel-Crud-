
<?php $__env->startSection('main'); ?>
<h1 class='text-center text-success py-5 mt-5'> Welcome of CRUD Operation</h1>
<section class='py-5'>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <table class='table table-hover table-bordered border-success text-center'>
                        <thead class="table-info">
                            <tr>
                                <th>NO</th>
                                <th>Name</th>                               
                                <th>Image</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->index+1); ?></td>
                                <td><a href="products/<?php echo e($product->id); ?>/show" class='text-dark'><?php echo e($product->name); ?></a> </td>
                                <td><img src="products/<?php echo e($product->image); ?>" alt="" class='rounded-circle' width='50' height='50'></td>                             
                                <td>
                                  <a href="products/<?php echo e($product->id); ?>/edit" class='btn btn-primary btn-sm'>Edit</a>
                                  <a href="products/<?php echo e($product->id); ?>/delete" class='btn btn-danger btn-sm'>Del</a>

                                </td>                             
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\crud\resources\views/products/index.blade.php ENDPATH**/ ?>