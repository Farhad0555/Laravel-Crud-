
<?php $__env->startSection('main'); ?>
<section class='py-5'>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <form action="<?php echo e(route('products.store')); ?>" method='POST' enctype='multipart/form-data'>
                        <?php echo csrf_field(); ?>
                            <div class="card-header">
                                <h4>Fill up the info</h4>
                            </div>
                            <div class="card-body">
                            <div class="form-group row py-2">
                                <label class="col-md-3 text-center">Name</label>
                                <div class="col-md-9">
                                    <input type="text" name='name' class='form-control' value="<?php echo e(old('name')); ?>">
                                    <?php if($errors->has('name')): ?>
                                    <span class='text-danger'><?php echo e($errors->first('name')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group row py-2">
                                <label class="col-md-3 text-center">Description </label>
                                <div class="col-md-9">
                                    <input type="text" name='description' class='form-control' value="<?php echo e(old('description')); ?>">
                                    <?php if($errors->has('description')): ?>
                                    <span class='text-danger'><?php echo e($errors->first('description')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group row py-2">
                                <label class="col-md-3 text-center"> Image </label>
                                <div class="col-md-9">
                                    <input type="file" name='image' class='form-control' value="<?php echo e(old('image')); ?>">
                                    <?php if($errors->has('image')): ?>
                                    <span class='text-danger'><?php echo e($errors->first('image')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group row py-2">
                                <label class="col-md-3 text-center"></label>
                                <div class="col-md-9">
                                    <input type="submit" name='btn' class='btn btn-outline-success form-control'>
                                </div>
                            </div>
                            </div>
                            </form>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\crud\resources\views/products/create.blade.php ENDPATH**/ ?>