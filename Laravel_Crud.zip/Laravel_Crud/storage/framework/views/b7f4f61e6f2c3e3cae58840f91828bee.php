
<?php $__env->startSection('main'); ?>
<section class='py-5'>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card p-4">
                    <div class="card-body">
                        <h3>Name : <?php echo e($product->name); ?></h3>
                        <h3>Description: <?php echo e($product->description); ?></h3>                     
                        <p> <img src="http://localhost:8080/laravel/crud/public/products/<?php echo e($product->image); ?>" class='rounded'alt="" width='100%'>  </p>                     
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\crud\resources\views/products/show.blade.php ENDPATH**/ ?>