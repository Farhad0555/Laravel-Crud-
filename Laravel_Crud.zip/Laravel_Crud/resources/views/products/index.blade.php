@extends('layouts.app')
@section('main')
<h1 class='text-center text-success py-5 mt-5'> Welcome of CRUD Operation</h1>
<section class='py-5'>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <table class='table table-hover table-bordered border-success text-center'>
                        <thead class="table-info">
                            <tr>
                                <th>NO</th>
                                <th>Name</th>                               
                                <th>Image</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($products as $product)
                            <tr>
                                <td>{{$loop->index+1}}</td>
                                <td><a href="products/{{$product->id}}/show" class='text-dark'>{{$product->name}}</a> </td>
                                <td><img src="products/{{$product->image}}" alt="" class='rounded-circle' width='50' height='50'></td>                             
                                <td>
                                  <a href="products/{{$product->id}}/edit" class='btn btn-primary btn-sm'>Edit</a>
                                  <a href="products/{{$product->id}}/delete" class='btn btn-danger btn-sm'>Del</a>

                                </td>                             
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
  @endsection