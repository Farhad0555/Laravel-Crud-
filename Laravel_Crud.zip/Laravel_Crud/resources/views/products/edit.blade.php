@extends('layouts.app')
@section('main')
 <section class='py-5'>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <form method='POST' action="{{route('products.update',$product->id)}}"  enctype='multipart/form-data'>
                        @csrf
                        @method('PUT')
                            <div class="card-header">
                                <h4 class='text-muted'>Update the info of :: {{$product->name}}</h4>
                            </div>
                            <div class="card-body">
                            <div class="form-group row py-2">
                                <label class="col-md-3 text-center">Name</label>
                                <div class="col-md-9">
                                    <input type="text" name='name' class='form-control' value="{{old('name',$product->name)}}">
                                    @if($errors->has('name'))
                                    <span class='text-danger'>{{$errors->first('name')}}</span>
                                    @endif
                                </div>
                            </div>
                            <div class="form-group row py-2">
                                <label class="col-md-3 text-center">Description </label>
                                <div class="col-md-9">
                                    <input type="text" name='description' class='form-control' value="{{old('description',$product->description)}}">
                                    @if($errors->has('description'))
                                    <span class='text-danger'>{{$errors->first('description')}}</span>
                                    @endif
                                </div>
                            </div>
                            <div class="form-group row py-2">
                                <label class="col-md-3 text-center"> Image </label>
                                <div class="col-md-9">
                                    <input type="file" name='image' class='form-control' value="{{old('image',$product->image)}}">
                                    @if($errors->has('image'))
                                    <span class='text-danger'>{{$errors->first('image')}}</span>
                                    @endif
                                </div>
                            </div>
                            <div class="form-group row py-2">
                                <label class="col-md-3 text-center"></label>
                                <div class="col-md-9">
                                    <input type="submit" name='updateBTN' class='btn btn-outline-success form-control'>
                                </div>
                            </div>
                            </div>
                            </form>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection