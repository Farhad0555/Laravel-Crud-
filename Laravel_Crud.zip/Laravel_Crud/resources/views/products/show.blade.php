@extends('layouts.app')
@section('main')
<section class='py-5'>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card p-4">
                    <div class="card-body">
                        <h3>Name : {{$product->name}}</h3>
                        <h3>Description: {{$product->description}}</h3>                     
                        <p> <img src="http://localhost:8080/laravel/crud/public/products/{{$product->image}}" class='rounded'alt="" width='100%'>  </p>                     
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection